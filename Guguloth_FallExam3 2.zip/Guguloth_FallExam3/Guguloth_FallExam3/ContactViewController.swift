//
//  ContactViewController.swift
//  Guguloth_FallExam3
//
//  Created by Jitender SIngh on 11/30/23.
//

import UIKit

class ContactViewController: UIViewController {
    
    
    @IBOutlet weak var conNameOL: UILabel!
    
    
    @IBOutlet weak var conNumberOl: UILabel!
    
    var con = Contact(contactFirstName: "Hello",contactLastName : "Hi", contactNumber: 1)
    
    override func viewDidLoad() {
        
        
        
        super.viewDidLoad()
        
        let firstInitial = con.contactFirstName.first?.description ?? ""
        let lastInitial = con.contactLastName.first?.description ?? ""
        
        conNameOL.text="Initials : \(firstInitial) \(lastInitial)"
        
        conNumberOl.text="Contact Number : \(con.contactNumber)"

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
