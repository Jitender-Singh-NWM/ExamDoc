//
//  ViewController.swift
//  Guguloth_FallExam3
//
//  Created by Jitender SIngh on 11/30/23.
//

import UIKit


class Contact {
    
    
    
    var contactFirstName: String
    var contactLastName: String
    var contactNumber: Int
    
    init(contactFirstName: String,contactLastName: String, contactNumber: Int) {
        self.contactFirstName = contactFirstName
        self.contactLastName=contactLastName
        self.contactNumber = contactNumber
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = ConTableView.dequeueReusableCell(withIdentifier: "conCell", for: indexPath)
        cell.textLabel?.text="\(contactArray[indexPath.row].contactFirstName) \(contactArray[indexPath.row].contactLastName)"
        return cell
        
    }
    
    
    @IBOutlet weak var ConTableView: UITableView!
    
    var contactArray = [Contact] ();
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ConTableView.delegate=self
        ConTableView.dataSource=self
        
        let contact1 = Contact(contactFirstName: "James😍",contactLastName : "Henry", contactNumber: 872-362-234)
        
        let contact2 = Contact(contactFirstName: "Jhony😇",contactLastName : "Henry", contactNumber: 872-361-234)
        let contact3 = Contact(contactFirstName: "Annie😇",contactLastName : "Holmes", contactNumber: 872-361-234)
        let contact4 = Contact(contactFirstName: "Tom🤣",contactLastName : "Holmes", contactNumber: 872-36-1235)
        let contact5 = Contact(contactFirstName: "Tim🤨",contactLastName : "Holmes", contactNumber: 872-361-239)
        let contact6 = Contact(contactFirstName: "George😇",contactLastName : "Holmes", contactNumber: 872-361-270)
        let contact7 = Contact(contactFirstName: "Jolly😇",contactLastName : "Holmes", contactNumber: 872-361-2652)
        let contact8 = Contact(contactFirstName: "Jhonson😇",contactLastName : "Holmes", contactNumber: 872-361-2975)
        let contact9 = Contact(contactFirstName: "Jameson😇",contactLastName : "Holmes", contactNumber: 872-361-2327)
        let contact10 = Contact(contactFirstName: "Jim😇",contactLastName : "Holmes", contactNumber: 872-361-2546)
        
        
        contactArray.append(contact1)
        contactArray.append(contact2)
        contactArray.append(contact3)
        contactArray.append(contact4)
        contactArray.append(contact5)
        contactArray.append(contact6)
        contactArray.append(contact7)
        contactArray.append(contact8)
        contactArray.append(contact9)
        contactArray.append(contact10)
       
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "consegue"){
            
            let destination = segue.destination as! ContactViewController
            
            destination.con=contactArray[(ConTableView.indexPathForSelectedRow?.row)!]
        }
            
        
    }
    
    


}

